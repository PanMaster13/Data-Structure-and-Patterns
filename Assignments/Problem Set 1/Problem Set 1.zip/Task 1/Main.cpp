#include <iostream>
using namespace std;

//This is a Main loop
int main()
{
	//This outputs text in the console window
	cout << "Program Start" << endl;

	//This pauses the console window while waiting for any input
	system("pause");

	//This ends the program
	return 0;
}