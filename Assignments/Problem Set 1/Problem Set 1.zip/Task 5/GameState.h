#pragma once

enum GameState
{
	PASSIVE, ACTIVE, DESTROYED
	//Enums in C++ store values in 0, 1, 2, ...
};
