#pragma once

enum UnitCat
{
	LAND, AIR, WATER, BUILDING, TERRAIN
	//Enums in C++ store values in 0, 1, 2, ...
};